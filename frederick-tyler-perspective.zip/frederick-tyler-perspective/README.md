# 弗雷德里克·泰勒 · 思维视角 Skill

> 技术不对称、隐蔽战略与计划反噬。

属于 Zero Wong 的[三体人物思维专区](https://github.com/zhaohuang321/three-body-thinking-skills)。

## 内容

- `SKILL.md`：思维模型、调用方式与适用边界。
- `references/research/`：来源、人物决策分析与验证记录。

## 使用

下载本仓库，将完整目录命名为 `frederick-tyler-perspective`，放入 Codex 的 skills 目录，重新开始会话后调用。

示例：**“用弗雷德里克·泰勒的视角，分析这个问题，并指出框架的局限。”**

也可以直接阅读 SKILL.md，把它作为思考与讨论的参考。

## 来源与边界

蒸馏流程参考 [女娲 · Skill造人术](https://github.com/alchaincyf/nuwa-skill)，创建者花叔。第三方流程许可见 THIRD_PARTY_LICENSES/nuwa-skill-LICENSE。该许可不代表小说、人物或本仓库所有内容获得统一授权。具体资料来源见调研笔记。

本项目是文学分析与方法整理，包含剧透。原著事实、研究解释和现实推断应分别判断；不是刘慈欣或原著人物的官方立场。
